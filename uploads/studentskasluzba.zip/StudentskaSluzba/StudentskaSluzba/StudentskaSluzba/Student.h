#pragma once
#pragma once

#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

class Student
{

	char* ime = nullptr, * prezime = nullptr;
	int brojIndeksa = 0;
	int maxBrojIspita;
	int brojPolozenihIspita = 0;
	vector<int> ocene;

public:
	Student(int maxBr) {
		ime = new char[30];
		prezime = new char[30];
	}


	~Student() {
		delete ime;
		delete prezime;
	}


	Student(const Student& s) {
		ime = new char[30];
		prezime = new char[30];
		strcpy(ime, s.ime);
		strcpy(prezime, s.prezime);
		brojIndeksa = s.brojIndeksa;
		maxBrojIspita = s.maxBrojIspita;
		brojPolozenihIspita = s.brojPolozenihIspita;
		ocene = s.ocene;
	}


	inline int getBrojIndeksa() const {
		return brojIndeksa;
	}


	int getBrojPolozenihIspita() const
	{
		return brojPolozenihIspita;
	}


	void dodajOcenu(int ocena) {
		if (ocena < 5 || ocena > 10) {
			cout << "Neispravna ocena" << endl;
			return;
		}
		else {
			ocene.push_back(ocena);
			if (ocena > 5) {
				brojPolozenihIspita++;
			}
		}
	}

	
	void ucitajPodatke(char* imes, char* prezimes, int brojIndeksas) {
		strcpy(ime, imes);
		strcpy(prezime, prezimes);
		brojIndeksa = brojIndeksas;
	}


	void ispisiOcene() {
		cout << "Ocene: ";
		sort(ocene.begin(), ocene.end());
		for (int i = ocene.size() - 1; i >= 0; i--) {
			cout << ocene[i] << " ";
		}
	}

	void promeniImePrezime() {
		cout << "Unesite novo ime" << endl;
		fgets(ime, 30, stdin);
		ime[strlen(ime) - 1] = '\0';

		cout << "Unesite novo prezime" << endl;
		fgets(prezime, 30, stdin);
		prezime[strlen(prezime) - 1] = '\0';
	}


	void ispis() {
		FILE* file = fopen("izlaz.txt", "w"); 
		fprintf(file, "Ime: %s\n", ime);
		fprintf(file, "Prezime: %s\n", prezime);
		fprintf(file, "Broj indeksa: %d\n", brojIndeksa);
		fprintf(file, "Ocene: ");

		sort(ocene.begin(), ocene.end());
		for (int i = ocene.size() - 1; i >= 0; i--) {
			fprintf(file, "%d ", ocene[i]);
		}
		fprintf(file, "\n");
		fclose(file); 
	}
};
