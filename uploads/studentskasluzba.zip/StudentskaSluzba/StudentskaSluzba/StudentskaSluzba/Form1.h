#pragma once
#include <string>
#include <cstring>
#include "Student.h";
#using <mscorlib.dll>

namespace CppCLRWinformsProjekt {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Runtime::InteropServices;

	/// <summary>
	/// Zusammenfassung f�r Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzuf�gen.
			//
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ textIme;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ textPrezime;
	private: System::Windows::Forms::TextBox^ textBrojIndeksa;
	private: System::Windows::Forms::TextBox^ textUnesiteocenu;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ btbDodaj;


	private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->textIme = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textPrezime = (gcnew System::Windows::Forms::TextBox());
			this->textBrojIndeksa = (gcnew System::Windows::Forms::TextBox());
			this->textUnesiteocenu = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->btbDodaj = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18));
			this->label1->Location = System::Drawing::Point(327, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(196, 40);
			this->label1->TabIndex = 0;
			this->label1->Text = L"STUDENTI";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->label2->Location = System::Drawing::Point(47, 119);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(165, 32);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Unesite Ime";
			// 
			// textIme
			// 
			this->textIme->Location = System::Drawing::Point(412, 119);
			this->textIme->Name = L"textIme";
			this->textIme->Size = System::Drawing::Size(227, 26);
			this->textIme->TabIndex = 2;
			this->textIme->TextChanged += gcnew System::EventHandler(this, &Form1::textIme_TextChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->label3->Location = System::Drawing::Point(49, 191);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(223, 32);
			this->label3->TabIndex = 3;
			this->label3->Text = L"Unesite Prezime";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->label4->Location = System::Drawing::Point(49, 252);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(276, 32);
			this->label4->TabIndex = 4;
			this->label4->Text = L"Unesite Broj Indeksa";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->label5->Location = System::Drawing::Point(49, 313);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(203, 32);
			this->label5->TabIndex = 5;
			this->label5->Text = L"Unesite Ocenu";
			// 
			// textPrezime
			// 
			this->textPrezime->Location = System::Drawing::Point(412, 191);
			this->textPrezime->Name = L"textPrezime";
			this->textPrezime->Size = System::Drawing::Size(227, 26);
			this->textPrezime->TabIndex = 6;
			this->textPrezime->TextChanged += gcnew System::EventHandler(this, &Form1::textPrezime_TextChanged);
			// 
			// textBrojIndeksa
			// 
			this->textBrojIndeksa->Location = System::Drawing::Point(412, 258);
			this->textBrojIndeksa->Name = L"textBrojIndeksa";
			this->textBrojIndeksa->Size = System::Drawing::Size(227, 26);
			this->textBrojIndeksa->TabIndex = 7;
			this->textBrojIndeksa->TextChanged += gcnew System::EventHandler(this, &Form1::textBrojIndeksa_TextChanged);
			// 
			// textUnesiteocenu
			// 
			this->textUnesiteocenu->Location = System::Drawing::Point(412, 320);
			this->textUnesiteocenu->Name = L"textUnesiteocenu";
			this->textUnesiteocenu->Size = System::Drawing::Size(227, 26);
			this->textUnesiteocenu->TabIndex = 8;
			this->textUnesiteocenu->TextChanged += gcnew System::EventHandler(this, &Form1::textUnesiteocenu_TextChanged);
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->button1->Location = System::Drawing::Point(622, 471);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(161, 50);
			this->button1->TabIndex = 9;
			this->button1->Text = L"Kraj";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// btbDodaj
			// 
			this->btbDodaj->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14));
			this->btbDodaj->Location = System::Drawing::Point(53, 471);
			this->btbDodaj->Name = L"btbDodaj";
			this->btbDodaj->Size = System::Drawing::Size(128, 50);
			this->btbDodaj->TabIndex = 10;
			this->btbDodaj->Text = L"Dodaj";
			this->btbDodaj->UseVisualStyleBackColor = true;
			this->btbDodaj->Click += gcnew System::EventHandler(this, &Form1::btbDodaj_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->ClientSize = System::Drawing::Size(878, 544);
			this->Controls->Add(this->btbDodaj);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textUnesiteocenu);
			this->Controls->Add(this->textBrojIndeksa);
			this->Controls->Add(this->textPrezime);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->textIme);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void textIme_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textPrezime_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void textBrojIndeksa_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void textUnesiteocenu_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	Close();
}
private: System::Void btbDodaj_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ ime = textIme->Text;
	String^ prezime = textPrezime->Text;
	String^ brIndexa = textBrojIndeksa->Text;
	String^ ocena = textUnesiteocenu->Text;
	char* ime2 = (char*)Marshal::StringToHGlobalAnsi(ime).ToPointer();
	char* prezime2 = (char*)Marshal::StringToHGlobalAnsi(prezime).ToPointer();
	int brIndexa2 = Int32::Parse(brIndexa);
	int ocena2 = Int32::Parse(ocena);
	Student student(30);
	student.ucitajPodatke(ime2, prezime2, brIndexa2);
	student.dodajOcenu(ocena2);
	Student student2(student);
	student2.ispis();//ispis podataka u fajl izlaz.txt
	MessageBox::Show("Dodato je u folder izlaz");
}
};
}
